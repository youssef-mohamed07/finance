"""
Service layer for business logic
"""