"""
Core application components
"""