"""
Utility functions and helpers
"""