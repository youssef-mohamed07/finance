"""
API layer for HTTP endpoints
"""